<html>
<head>
</head>
<link rel="stylesheet" type="text/css" href="loginstyle2.css">
<form action="chall1.php" method="POST">
<br><br>
<br>
<br>
<div class="register-box">
<h1>Event Registration -Convention Center </h1>
<b>Event name :</b>
<input type="text" name="name" required >
<br>
<b>Username </b>
<input type="text" name="username" required>
<b>Date:</b><br>
<b>From:-</b>
<input type="date" name="dfrom" required>
<b>To:</b>
<input type="date" name="dto" required>
<br>
<b>Time</b><br>
<b>From:-</b>
<input type="time" name="tfrom" required>
<b>To:</b>
<input type="time" name="tto" required>
<br>
<!--<b>Requirements for Hall</b><br>
  <input type="checkbox" name="req" > Power and generator<br>
  <input type="checkbox" name="req"  > Audio Box<br>
  <input type="checkbox" name="req" > Ac<br>
  <input type="checkbox" name="req"  > VIP room<br> -->
<input type="submit">
</div>
<br><br>
</form>
</body>
</html>
