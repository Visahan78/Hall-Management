<!DOCTYPE html>
<html>
<head>
</head>
<link rel="stylesheet" type="text/css" href="loginstyle1.css">
<form action="insert11.php" method="POST">
<br><br>
<br>
<br>
<div class=register-box>
<h1> Sign-Up </h1>
<b>UserName:</b><br>
<input type="text" name="username" required><br>
<b>Password:</b><br>
<input type="password" name="password" required >
   <br>
<b>Name</b><br>
<input type="text" name="name" required autofocus>
<br>
<b>Department:</b><br>
   <select type="text" name="department" >
   <option value="select department" > Select Department </option>
  <option >MECHANICAL</option>
  <option >MECHATRONICS</option>
  <option >ECE </option>
  <option> EEE</option> 
  <option> COMPUTERSCIENCE</option> 
  <option> INFORMATION TECHNOLOGY</option> 
   </select>
<br>
<b>Email</b><br>
<input type="email" name="email" required >
<br>
<b>Phone no</b><br>
<input type="int" name="phoneno">
<br>
<input type="submit" value="Submit">
<br>
</div>
</form>
</body>
</html>
