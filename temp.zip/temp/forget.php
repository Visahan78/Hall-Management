<html>
<head>
<title>Retrieval of Username</title>
<link rel="stylesheet" type="text/css" href="loginstyle3.css">
<div class=login-box>
<h1>Forget Password</h1>
<form action="forget1.php" method="post">
Username:-
<input type="text" name="username">
Mail id:-
<input type="email" name="email">
<input type="submit">
</div>
</form>
</body>
</head>
</html>