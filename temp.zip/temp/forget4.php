<html>
<head>
<title> Change Password </title>
<body>
<form action="forget5.php" method="post">
<b> Change Password </b>
<input type="password" name="password">
<input type="submit">
</form>
</body>
</head>
</html>