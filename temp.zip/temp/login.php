<html>
<title>  LOGIN </title>
<link rel="stylesheet" type="text/css" href="loginstyle.css">
<body>
<div class="login-box">
<h1><font face="jokerman" > LOGIN </h1> </font>
<form action= "process1.php" method="post">
<b> UserName:</b>
<input type="text" name="username" placeholder="enter the name" required><br><br>
<b> Password:</b>
<input type="password" name="password" placeholder="enter the password" required >
<br> <br>
<input type="submit">
  <a href="forget.php">  Forget password ? </a><br><br>
 <input type="button" value="Register" onclick="window.location.href='register.php'">
</div>	<br>
</form>
</body>
</html>  