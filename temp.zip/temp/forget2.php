<html>
<head>
<title> OTP </title>
<form action="forget3.php" method="post">
<link rel="stylesheet" type="text/css" href="loginstyle3.css">
<div class=login-box>
<b>Enter ur Otp </b>
<input type="int" name="otp1">
<input type="submit">
</div>
</head>
</html>
