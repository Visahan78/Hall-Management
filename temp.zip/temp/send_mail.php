<?php
if(isset($_POST['name']))
{
		$name=$_POST['name'];
}
if(isset($_POST['email']))
{
		$email=$_POST['email'];
}
if(isset($_POST['message']))
{
		$message=$_POST['message'];
}
$subject = "Listed Queries";
$headers = "From: visahan.vnr@gmail.com" . "\r\n" .
"CC: $name";
echo "Your Queries has been Successfully registered";
mail($email,$subject,$message,$headers);
?>